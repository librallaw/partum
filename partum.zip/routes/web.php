<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home.home');
});

Auth::routes();


    Route::get('/logout', 'HomeController@logout')->name('logout');
    Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/setup', 'HomeController@setup')->name('setup');
    Route::get('/setup/bank', 'HomeController@addbank')->name('addbank');
    Route::post('/setup/bank', 'HomeController@doAddBank')->name('doAddBank');
    Route::get('/savings/initial', 'HomeController@showFirstPayment')->name('showFirstPayment');
    Route::post('/savings/initial', 'HomeController@doFirstPayment')->name('doFirstPayment');
    Route::post('/pay2', 'PaymentController@gateway')->name('gateway');
    Route::post('/pay', 'PaymentController@redirectToGateway')->name('pay');
    Route::get('/payment/callback', 'PaymentController@handleGatewayCallback');



    Route::group(['middleware' => ['auth','setup']], function () {
    Route::get('/dashboard', 'UserController@showDashboard')->name('showDashboard');
    Route::post('/savings/initial', 'UserController@doFirstPayment')->name('doFirstPayment');

});


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Partum Gateway</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!--All css  are here-->

    <!--Bootstrap css here-->
    <link rel="stylesheet" href="assets/css/bootstrap.css">

    <!--Font-Awsome css here-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--Owl-carousel css here-->
    <link rel="stylesheet" href="assets/plugins/owl/owl.carousel.css">
    <link rel="stylesheet" href="assets/plugins/owl/owl.theme.css">
    <link rel="stylesheet" href="assets/plugins/owl/owl.transitions.css">

    <!--Custon css here-->
    <link rel="stylesheet" href="assets/css/custom.css">


    <!--Responsive css here-->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/plugins/aos-master/aos.css"/>

    <!--Slider Custon css here-->
    <link rel="stylesheet" href="assets/css/header-fix.css">


</head>
<body>

<div class="se-pre-con"></div>

<!--TOP SECTION START HERE-->

<section id="topNav">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 p0">
                <div class="col-md-6 col-sm-6 col-xs-12 p0">
                    <ul class="list-inline">
                        <li><a href="javascript:;">Mobile : +1 987654 - 3210</a></li>
                        <li><a href="javascript:;">Email : info@example.com</a></li>
                    </ul>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12" >
                    <ul class="list-inline floatRight">
                        <li><a href="javascript:;"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="javascript:;"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="javascript:;"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!--TOP SECTION END HERE-->

<!-- NAVIGATION -->
<nav class="navbar navbar-default fixedNavbar">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header logoo">
            <button id="tog-btn" type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#home-section"><img class="img-responsive" src="assets/images/logo.png"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right hidden-xs hidden-sm">
                <li class="gold"><a href="javascript:;"><button class="  btn btn-gradient outline-button" style="margin-bottom: 0px;" data-toggle="modal" data-target="#pop-register"><div style="background: #1C589B;transition: all 0.3s;">Register</div></button></a></li>
            </ul>
            <ul id="navigation" class="nav navbar-nav navbar-right">
                <li><a class="active" href="#home-section">Home</a></li>
                <li><a href="#about-section">About</a></li>
                <li><a href="#how">How?</a></li>
                <li><a href="#extra">Extra</a></li>
                <!--<li><a href="#features-section">Features</a></li>-->
                <li><a href="#testimonial-section">Testimonial</a></li>
                <li><a href="#contact-section">Contact</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right visible-xs visible-sm">
                <li class="gold" style="border-top: 1px solid rgba(255,255,255,0.1)"><a href="javascript:;" data-toggle="modal" data-target="#pop-register">Register</a></li>
            </ul>
        </div>

    </div>
</nav>
<!-- NAVIGATION -->


<!-- HEADER -->
<section id="home-section" class="header-bg">
    <div class="gradient sectionP60 header-pad">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-md-5 col-sm-5 col-xs-12 header-text sectionP60">
                            <h1 class="rL white">Partum Gateway</h1>
                            <h1 class="rL white">Make it Happen!</h1>
                            <p class="rL white">partumgateway.com securely makes saving possible by combining discipline plus flexibility to make you grow your savings & better manage your finances.</p>
                            <button class="btn btn-gradient" data-aos="zoom-in-up" data-aos-duration="800">Start Saving</button>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 pull-right">
                            <div class="login-div centered" data-aos="fade-up" data-aos-duration="1000">
                                <div class="head">
                                    <h3 class="purple oR m0">LOGIN</h3>
                                    <p class="light oR">Enter your credentials to login.</p>
                                </div>
                                <form action="">
                                    <div class="body">
                                        <div class="input-box">
                                            <input placeholder="Email or Username" type="text" required>
                                            <span style="position: absolute"><i class="fa fa-user"></i></span>
                                        </div>
                                        <div class="input-box">
                                            <input placeholder="Password" type="password" required>
                                            <span style="position: absolute"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                    <div class="foot">
                                        <a href="javascript:;" class="forgot pull-left"><small>forgot your password?</small></a>
                                        <button class="btn btn-gradient W100 pull-right" data-aos="zoom-in-up" data-aos-duration="800">Login!</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- HEADER -->

<!-- About -->
<section id="about-section" class="" style="padding-bottom: 60px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="services-div margin-minus" data-aos="fade-up" data-aos-duration="1000">
                    <div class="col-md-3 col-sm-6 col-xs-12 text-center br service-hover">
                        <div class="service" data-aos="zoom-in" data-aos-duration="1000">
                            <div class="service-icon">
                                <i class="fa fa-lock"></i>
                            </div>
                            <div class="service-desc">
                                <h4 class="blue oB">Secure</h4>
                                <p>Partum Gateway uses SSL protection to ensure that your data is protected from Cyber theft</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 text-center br b0 service-hover">
                        <div class="service" data-aos="zoom-in" data-aos-duration="1000">
                            <div class="service-icon">
                                <i class="fa fa-pencil"></i>
                            </div>
                            <div class="service-desc">
                                <h4 class="blue oB">Easy to use </h4>
                                <p>Our well designed user interface makes is easy for you to easily navigate through our website</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 text-center br b0 service-hover">
                        <div class="service" data-aos="zoom-in" data-aos-duration="1000">
                            <div class="service-icon">
                                <i class="fa fa-clock-o"></i>
                            </div>
                            <div class="service-desc">
                                <h4 class="blue oB">24/7 customers Support</h4>
                                <p>Our 24/7 customers representatives are always available to help you out</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-12 text-center br service-hover">
                        <div class="service" data-aos="zoom-in" data-aos-duration="1000">
                            <div class="service-icon">
                                <i class="fa fa-money"></i>
                            </div>
                            <div class="service-desc">
                                <h4 class="blue oB">Payout Anytime</h4>
                                <p>Thats right! You decided when you get your money. Its that Simple.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 text-center">
                    <div id="wwa">
                        <div class="heading-text" data-aos="fade-up" data-aos-duration="1000">
                            <span class="gold-gradient-color">WHO WE ARE?</span>
                        </div>
                        <p class="light oR" data-aos="fade-up" data-aos-duration="1000"><strong>PARTUM GATEWAY</strong> is an online savings platform that affords its users the golden opportunity to adequately develop and manage a stable financial life by intuitively growing their savings.
                            With <strong>PARTUM GATEWAY</strong>, you are just one more deposit away from your Treasured Future!  <!--Our core team brings together top class talent from the worlds of finance, tech and beyond, representing a strong combination of proven skills and passion to ensure that everyone can better manage their finances.--></p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About -->
<section class="counter-bg">
    <div class="sectionP40 blue-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-5 col-md-offset-0 col-sm-10 col-sm-offset-1 col-xs-12">
                        <div class="responsive" data-aos="fade-right" data-aos-duration="1000">
                            <div class="heading-text">
                                <span class="gold-gradient-color">Little bit of stats.</span>
                            </div>
                            <p class="light2 oL" style="font-size: 16px;">We afford our users the golden opportunity to adequately develop and manage a stable financial life by intuitively growing their savings.

                            </p>

                        </div>
                    </div>
                    <div id="counter" class="col-md-5 col-sm-12 col-xs-12 pull-right resPad0">
                        <div class="col-md-6 col-sm-3 col-xs-6 br bb">
                            <div class="numbers text-center" data-aos="zoom-in" data-aos-duration="1000">

                                <p class="white oR gold-gradient-color">Safe & Secure</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-3 col-xs-6 bb">
                            <div class="numbers text-center" data-aos="zoom-in" data-aos-duration="1000">

                                <p class="white oR ">Safe,Secure And Convenient

                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-3 col-xs-6 br">
                            <div class="numbers text-center" data-aos="zoom-in" data-aos-duration="1000">

                                <p class="white oR">Mobile Privacy And Security</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-3 col-xs-6">
                            <div class="numbers text-center" data-aos="zoom-in" data-aos-duration="1000">

                                <p class="white oR gold-gradient-color">Cash Out Anytime</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="how" class="hiw-bg">
    <div class="sectionP60 grey-bg-o">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 text-center">
                        <div data-aos="fade-up" data-aos-duration="1000">
                            <div class="heading-text">
                                <span class="gold-gradient-color">How it works</span>
                            </div>
                            <p class="light oR" style="font-size: 16px;">You can kick start your future with Patrum Gateway services by just following the simple steps below.</p>
                        </div>
                    </div>
                    <div class="col-md-12 col-md-offset-0 col-sm-10 col-sm-offset-1 col-xs-12 p0 sectionP40">
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div data-aos="fade-up" data-aos-duration="1000">
                                <img class="img-responsive centered" src="assets/images/laptop2.png"/>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12 col-xs-12 sectionP20 pull-right">
                            <div class="acordian active gradient-accordian" data-aos="fade-up" data-aos-duration="1000">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-md-12 col-sm-12 col-xs-12 pull-right">
                                        <div class="acordian-desc res-txt-center">
                                            <i class="fa fa-user"></i><span class="rM">Activate a PARTUM GATEWAY Account </span>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="acordian-body res-txt-center">
                                            <span class="white rL">Activating a PARTUM GATEWAY accounts is fast and very easy to do. All you need is to sign up for a new account by providing your basic details such as Profile Details, Contact Details, Card Details, BVN etc. Also, you get to set up your account by deciding how much you want to save and how regularly you would like to fund your PARTUM GATEWAY. That’s it!</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="acordian gradient-accordian" data-aos="fade-up" data-aos-duration="1000">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-md-12 col-sm-12 col-xs-12 pull-right">
                                        <div class="acordian-desc res-txt-center">
                                            <i class="fa fa-building"></i><span class="rM">Build your Treasure Savings</span>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="acordian-body res-txt-center">
                                            <span class="white rL">Based on your saving preferences, we can make daily, weekly or monthly deposits into your PARTUM GATEWAY from the funds on the provided debit card(s) synced to your account.
</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="acordian gradient-accordian" data-aos="fade-up" data-aos-duration="1000">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-md-12 col-sm-12 col-xs-12 pull-right">
                                        <div class="acordian-desc res-txt-center">
                                            <i class="fa fa-shopping-bag"></i><span class="rM">Collect your Treasure Savings</span>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="acordian-body res-txt-center">
                                            <span class="white rL">And here’s the best part you’ve been waiting for ... With just a few clicks, you can get some or all the funds in your treasure savings moved into your bank account! These monies will be transferred to you for FREE on the set withdrawal date on your account or at a basic 5% charge on any other day of your choice.</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Why Choose Us -->
<section id="extra" class="sectionP60">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-8">
                    <div class="responsive rsb"  data-aos="fade-right" data-aos-duration="1000">
                        <div class="heading-text">
                            <span class="blue-gradient-color"> Extra Package !!!</span>
                        </div>
                        <div class="heading-text">
                            <span class="gold-gradient-color"> Celebration Bonus</span>
                        </div>

                        <br>
                        <p class="light oR alert alert-info gold-gradient-bg sectionP40" style="color:white">
                            From the 5% service charge by PARTUM GATEWAY, all our members can also redeem an extra 2% of their savings for any celebration of their choice; be it birthdays, anniversaries, Easter, Christmas – you name it etc.
                            It’s that simple and that sweet.
                        </p>
                    </div>
                </div>
                <div class="col-md-4" align="center">
                    <img src = "assets/images/pig.png" class="img-responsive"/>
                    <!--<div class="video-embed pull-right" data-aos="fade-left" data-aos-duration="1000">-->
                    <!--<div class="thumb">-->
                    <!--<span><i class="gold-gradient-color fa fa-youtube-play"></i></span>-->
                    <!--</div>-->
                    <!---->

                    <!--&lt;!&ndash;-->
                    <!--<iframe width="533" height="300" src="https://www.youtube.com/embed/2LeOH9AGJQM?rel=0" frameborder="0" allowfullscreen></iframe>-->
                    <!--&ndash;&gt;-->
                    <!--&lt;!&ndash;<iframe src="https://player.vimeo.com/video/202406936?title=0&amp;byline=0&amp;portrait=0&amp;color=FDA10E&amp;autoplay=0" width="100%" height="300" autoplay="0" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></iframe>&ndash;&gt;-->
                    <!--</div>-->

                </div>
            </div>
        </div>
    </div>
</section>



<!-- Meet Our Team -->

<!-- What Can We Offer -->
<!-- Meet Our Team -->

<!-- Testimonials -->
<section id="testimonial-section" class="hiw-bg">
    <div class="blue-bg sectionP60">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 text-center">
                        <div  data-aos="fade-up" data-aos-duration="1000">
                            <div class="heading-text">
                                <span class="gold">WHY PEOPLE L<i class="fa fa-heart-o"></i>VE US?</span>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12 sectionP60" style="padding-bottom: 0">
                        <div id="testimonial">
                            <div class="item col-md-12">
                                <div class="testimonial">
                                    <div class="testi-text">
                                        <p class="white rL" >"I was informed about PiggyBank.ng last year (2017), i was not interested initially because of fear of fraudulent activities on-going on the internet. However, after seeing testimonies and finding out that it’s actually certified by the federal..</p>
                                        <span class="gold-gradient-color rM">Zinani Chuks</span>
                                        <small class="light2 or">Work</small>

                                    </div>
                                    <div class="testi-p-image">
                                        <div class="arrow-image"><img src="assets/images/testimonial/bottom-pic.png"></div>
                                        <div class="person-image"><div><img class="img-responsive" src="assets/images/testimonial/client-1.png"></div></div>
                                    </div>

                                </div>
                            </div>
                            <div class="item col-md-12">
                                <div class="testimonial">
                                    <div class="testi-text">
                                        <p class="white rL" >"It has changed my life in the very best way and i want to continue telling people about it and the importance of having savings especially for rainy days.Most people do not save because they think they dont know why they should save or why we do"
                                        </p>
                                        <span class="gold-gradient-color rM">Tom Ebelle</span>
                                        <small class="light2 or">Worker</small>


                                    </div>
                                    <div class="testi-p-image">
                                        <div class="arrow-image"><img src="assets/images/testimonial/bottom-pic.png"></div>
                                        <div class="person-image"><div><img class="img-responsive" src="assets/images/testimonial/client-1.png"></div></div>
                                    </div>

                                </div>
                            </div>
                            <div class="item col-md-12">
                                <div class="testimonial">
                                    <div class="testi-text">
                                        <p class="white rL" >something done consistently becomes a habit; a habit done over and over becomes a way of life i.e. a culture. If we look at our society, we have a spending culture as opposed to a savings culture. ... Most people do not save because they think they</p>
                                        <span class="gold-gradient-color rM">Chika Adamson</span>
                                        <small class="light2 or">Workeress</small>

                                    </div>
                                    <div class="testi-p-image">
                                        <div class="arrow-image"><img src="assets/images/testimonial/bottom-pic.png"></div>
                                        <div class="person-image"><div><img class="img-responsive" src="assets/images/testimonial/client-1.png"></div></div>
                                    </div>

                                </div>
                            </div>
                            <div class="item col-md-12">
                                <div class="testimonial">
                                    <div class="testi-text">
                                        <p class="white rL" >This app has been amazing, its slowly teaching me how to develop a great saving habit...Its amazing how much ive saved in just 2 months..Each time i want to order for anything, i ask myself if i'd die if i didn't get it that day, and the answer is..</p>
                                        <span class="gold-gradient-color rM">Udoh Imeh</span>
                                        <small class="light2 or">Farmer</small>

                                    </div>
                                    <div class="testi-p-image">
                                        <div class="arrow-image"><img src="assets/images/testimonial/bottom-pic.png"></div>
                                        <div class="person-image"><div><img class="img-responsive" src="assets/images/testimonial/client-1.png"></div></div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="gold-gradient-bg sectionP40">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-6 col-sm-7 col-xs-12 res-txt-center">
                    <h2 class="white rL m0" style="margin-top: 6px;">Why waste time?</h2>
                </div>
                <div class="col-md-6 col-sm-5 col-xs-12 res-txt-center">
                    <button class="btn btn-white-outline pull-right res-float-none" style="margin: 0">Start saving Now !</button>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Footer Section -->
<footer id="contact-section" class="sectionP60 dark-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-7 col-sm-7 col-xs-12 pull-right resCont">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="heading-text">
                            <span class="gold-gradient-color">Get in touch.</span>
                        </div>
                    </div>
                    <form action="">
                        <div class="col-md-12 col-sm-12 col-xs-12 p0">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="input-box">
                                    <input placeholder="Full Name" type="text" required>
                                    <span style="position: absolute"><i class="fa fa-user"></i></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="input-box">
                                    <input placeholder="Email Address" type="text" required>
                                    <span style="position: absolute"><i class="fa fa-envelope-o"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 p0">
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="input-box">
                                    <input placeholder="Mobile or Telephone" type="text" required>
                                    <span style="position: absolute"><i class="fa fa-phone"></i></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="input-box">
                                    <input placeholder="Subject" type="text" required>
                                    <span style="position: absolute"><i class="fa fa-puzzle-piece"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12 p0">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="input-box">
                                    <textarea placeholder="Type your message here..." name="" id="" cols="30" rows="5"></textarea>
                                    <span style="position: absolute"><i class="fa fa-comments"></i></span>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-gradient outline-button pull-right mtb20"><div style="background: #0C1222;transition: all 0.3s">Send <tag class="hidden-xs">Message</tag></div></button>
                    </form>
                </div>
                <div class="col-md-4 col-sm-5 col-xs-12 border-right resCompany">
                    <div class="company-desc logoo">
                        <a href="#home-section"><img class="img-responsive" src="assets/images/logo.png"/></a>
                        <p class="light2 rl">
                            Operations Office: No. 16, Boyle Street, Lagos Island, Lagos, Nigeria.
                            08093719000 (Mon-Fri from 9am-5pm)</p>
                    </div>

                    <div class="cont-us">
                        <p class="gold rL">Contact Us</p>
                        <div><a class="light2 g" href="javascript:;"><span class="oR">Landline : + 1123456789</span></a></div>
                        <div><a class="light2 g" href="javascript:;"><span class="oR">Mobile : +1 123456789</span></a></div>
                        <div><a class="light2 g" href="javascript:;"><span class="oR">Email : partum@email.com</span></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section -->

<!-- Copyright Section -->
<section class="sectionP20" style="background: #0b101d;">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="col-md-12">
                    <p class="light oR m0" style="opacity: .65">&copy; Copyright 2017, all rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Copyright Section -->

<!-- Scroll Back Top Button -->
<button onclick="topFunction()" id="myBtn" class="btn btn-gradient"><i class="visible-xs fa fa-arrow-up"></i><tag class="hidden-xs">Back To Top</tag></button>
<!-- Scroll Back Top Button -->


<!-- Popups Are Here -->
<popups>

    <!-- Register Popup -->
    <div id="pop-register" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" data-aos="zoom-in-up" data-aos-duration="800">&times;</button>
                    <h3 class="modal-title  blue oR m0">REGISTER</h3>
                    <span class="light oR" style="font-size: 14px">Enter your informations to register.</span>
                </div>
                <form action="">
                    <div class="modal-body">
                        <div class="input-box">
                            <input placeholder="Full Name" type="text" required>
                            <span style="position: absolute"><i class="fa fa-user"></i></span>
                        </div>
                        <div class="input-box">
                            <input placeholder="Email Address" type="email" required>
                            <span style="position: absolute"><i class="fa fa-envelope-o"></i></span>
                        </div>
                        <div class="input-box">
                            <input placeholder="Login Key" type="text" required>
                            <span style="position: absolute"><i class="fa fa-key"></i></span>
                        </div>
                        <div class="input-box">
                            <input placeholder="Confirm Login Key" type="text" required>
                            <span style="position: absolute"><i class="fa fa-key"></i></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-gradient" data-dismiss="modal">Register</button>
                    </div>
                </form>
            </div>

        </div>
    </div>


</popups>




<!-- All Javascripts -->


<!-- All Javascripts -->

<!-- Jquery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Bootstrap -->
<script type="text/javascript" src="assets/js/bootstrap.js"></script>

<!-- Nice Scroll -->
<script type="text/javascript" src="assets/plugins/niceScroll/niceScroll.min.js"></script>

<!-- Google Map -->

<!-- Video Background -->
<script type="text/javascript" src="assets/plugins/videoBg/jquery.vide.js"></script>

<!-- Owl Carousel -->
<script type="text/javascript" src="assets/plugins/owl/owl.carousel.js"></script>

<!-- Number Counter -->
<script type="text/javascript" src="assets/plugins/numScroll/numscroller-1.0.js"></script>

<!-- Scroll Animations aos-master js -->
<script src="assets/plugins/aos-master/aos.js"></script>

<!-- Common -->
<script type="text/javascript" src="assets/js/common.js"></script>

<!-- header-fix page js -->
<script type="text/javascript" src="assets/js/header-fix.js"></script>

<!-- All Javascripts -->
</body>
</html>

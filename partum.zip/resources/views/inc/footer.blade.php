<footer class="gx-footer">
    <div class="d-flex flex-row justify-content-between">
        <p> Copyright Company Name © 2018</p>

    </div>
</footer>
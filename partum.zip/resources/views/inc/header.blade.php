<header class="main-header">
    <div class="gx-toolbar">
        <div class="sidebar-mobile-menu d-block d-lg-none">
            <a class="gx-menu-icon menu-toggle" href="#menu">
                <span class="menu-icon"></span>
            </a>
        </div>

        <a class="site-logo" href="/">
            <img src="/images/logo.png" alt="Jumbo" title="Jumbo">
        </a>

       

    </div>
</header>
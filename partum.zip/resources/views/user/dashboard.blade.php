
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Partum Gateway - A Savings Site">
    <title>Dashboard - Partum Gateway</title>
    <!-- Site favicon -->
    <link rel='shortcut icon' type='image/x-icon' href='images/favicon.ico' />
    <!-- /site favicon -->

    <!-- Font Material stylesheet -->
    <link rel="stylesheet" href="/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <!-- /font material stylesheet -->

    <!--Weather stylesheet -->
    <link rel="stylesheet" href="/fonts/weather-icons-master/css/weather-icons.min.css">
    <!--/Weather stylesheet -->

    <!-- Bootstrap stylesheet -->
    <link href="/css/jumbo-bootstrap.css" rel="stylesheet">
    <!-- /bootstrap stylesheet -->

    <!-- Perfect Scrollbar stylesheet -->
    <link href="/node_modules/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
    <!-- /perfect scrollbar stylesheet -->

    <!-- c3 Chart's css file -->
    <link href="/node_modules/c3/c3.min.css" rel="stylesheet">
    <!-- /c3 chart stylesheet -->

    <!-- Chartists Chart's css file -->
    <link href="/node_modules/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- /chartists chart stylesheet -->

    <!-- Jumbo-core stylesheet -->
    <link href="/css/jumbo-core.min.css" rel="stylesheet">
    <!-- /jumbo-core stylesheet -->

    <!-- Color-Theme stylesheet -->
    <link id="override-css-id" href="/css/theme-dark-indigo.css" rel="stylesheet">
    <!-- Color-Theme stylesheet -->

</head>

<body id="body" data-theme="dark-indigo">

<!-- Loader Backdrop -->
<div class="loader-backdrop">
    <!-- Loader -->
    <div class="loader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"></circle>
        </svg>
    </div>
    <!-- /loader-->
</div>
<!-- loader backdrop -->

<!-- Page container -->
<div class="gx-container">

    <!-- Page Sidebar -->
@include("inc.sidebar")

    <!-- /page sidebar -->

    <!-- Main Container -->
    <div class="gx-main-container">

        <!-- Main Header -->

        @include("inc.header")
        <!-- /main header -->

        <!-- Main Content -->
        <div class="gx-main-content">
            <!--gx-wrapper-->
            <div class="gx-wrapper">
                <div class="animated slideInUpTiny animation-duration-3">
                    <div class="page-heading d-sm-flex justify-content-sm-between align-items-sm-center">
                        <h2 class="title mb-3 mb-sm-0"><a href="javascript:void(0)">
                                <i class="zmdi zmdi-assignment-returned zmdi-hc-fw"></i>

                            </a>Dashboard</h2>

                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                        <div class="col-sm-12">
                            <div class="gx-card ">
                                <div class="gx-card-header">
                                    <h3 class="card-heading">Savings Balance</h3>
                                </div>
                                <div class="row align-items-center">
                                    <div class="col-sm-5">
                                        <h1 class="chart-f30 font-weight-light mb-1">₦685K,000</h1>
                                        <span class="sub-heading ">1,900 in this month</span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="card border-0 shadow bg-blue text-white">
                                <div class="chart-header">
                                    <div class="chart-title">

                                        <p>Savings Graph</p>
                                    </div>
                                </div>
                                <div id="ct-chart" class="max-height-120"></div>
                            </div>
                        </div>
                            <div class="gx-card">
                                <div class="col-12">
                                    <table class="table table-striped table-condensed table-bordered">
                                        <thead>
                                        <tr>
                                            <td align="left">Bank Name</td>
                                            <td align="left"><b>GTB</b></td>
                                        </tr>
                                        <tr>
                                            <td align="left">Account Name</td>
                                            <td align="left"><b>LAWRENCE, LIBRAL CHIGOZIE</b></td>
                                        </tr>
                                        <tr>
                                            <td align="left">Account No.</td>
                                            <td align="left"><b>0118938348</b></td>
                                        </tr>

                                        </thead></table>
                                </div>
                            </div>



                            <div class="col-sm-12">
                                <div class="gx-card text-center">
                                    <div class="gx-card-header-color bg-primary">



                                        <div class="gx-card-hd-content text-white"><h4 class="mb-0">Lawrence Libral</h4>

                                        </div>
                                    </div>
                                    <div class="gx-card-body">
                                        <p>Last Login : 20 september 2019</p>
                                    </div>
                                </div>

                            </div>


                        </div>



                        <div class="col-sm-6">
                            <div class="col-md-12">
                                <h2> Recent Transactions</h2>

                            </div>
                            <div class="timeline-section clearfix">
                                <div class="timeline-item">
                                    <div class="timeline-badge timeline-img">
                                        <img src="images/pentagon.png" alt="Pentagon" title="Pentagon">
                                    </div>
                                    <div class="timeline-panel ">
                                        <div class="timeline-panel-header">

                                            <div class="timeline-heading">
                                                <h5>30 NOV, 2018</h5>
                                                <h3 class="timeline-title">Credit</h3>
                                            </div>
                                        </div>
                                        <div class="timeline-body">
                                            <p>₦100.00 added to savings.<br> Balance ₦200.00
                                                Memo: Savings Deposit [PG].<br> (Payment ID: NPB83eDSpAkqd)
                                                Transaction ID: CW4cffead118 <br>
                                                Date: Monday 9th of July 2018 02:56:31 PM
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="timeline-item">
                                    <div class="timeline-badge timeline-img">
                                        <img src="images/pentagon.png" alt="Pentagon" title="Pentagon">
                                    </div>
                                    <div class="timeline-panel ">
                                        <div class="timeline-panel-header">

                                            <div class="timeline-heading">
                                                <h5>20 APRIL, 2018</h5>
                                                <h3 class="timeline-title">Credit</h3>
                                            </div>
                                        </div>
                                        <div class="timeline-body">
                                            <p>₦100.00 added to savings.<br> Balance ₦200.00
                                                Memo: Savings Deposit [PG].<br> (Payment ID: NPB83eDSpAkqd)
                                                Transaction ID: CW4cffead118 <br>
                                                Date: Monday 9th of July 2018 02:56:31 PM
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="timeline-item">
                                    <div class="timeline-badge timeline-img">
                                        <img src="images/pentagon.png" alt="Pentagon" title="Pentagon">
                                    </div>
                                    <div class="timeline-panel ">
                                        <div class="timeline-panel-header">

                                            <div class="timeline-heading">
                                                <h5>11 MAY, 2018</h5>
                                                <h3 class="timeline-title">Credit</h3>
                                            </div>
                                        </div>
                                        <div class="timeline-body">
                                            <p>₦100.00 added to savings.<br> Balance ₦200.00
                                                Memo: Savings Deposit [PG].<br> (Payment ID: NPB83eDSpAkqd)
                                                Transaction ID: CW4cffead118 <br>
                                                Date: Monday 9th of July 2018 02:56:31 PM
                                            </p>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>



                        </div>



                    <div class="row">


                        <div class="col-md-8">



                        </div>
                    </div>





                </div>
            </div>
            <!--/gx-wrapper-->


            <!-- Footer -->
        @include("inc.footer")
            <!-- /footer -->

        </div>
        <!-- /main content -->

    </div>
    <!-- /main container -->



</div>
<!-- /page container -->


<div class="menu-backdrop fade"></div>
<!-- /menu backdrop -->

<!--Load JQuery-->
<script src="/node_modules/jquery/dist/jquery.min.js"></script>
<!--Bootstrap JQuery-->
<script src="/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!--Perfect Scrollbar JQuery-->
<script src="/node_modules/perfect-scrollbar/dist/perfect-scrollbar.min.js"></script>
<!--Big Slide JQuery-->
<script src="/node_modules/bigslide/dist/bigSlide.min.js"></script>
<!--chart-->
<script src="/node_modules/d3/d3.min.js"></script>
<script src="/node_modules/c3/c3.min.js"></script>
<script src="/node_modules/chartist/dist/chartist.min.js"></script>

<!--Custom JQuery-->
<script src="/js/functions.js"></script>
<script src="/js/custom/chart/dashboard-chart.js"></script>
</body>
</html>


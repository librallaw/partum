<?php

namespace App\Http\Controllers;

    use App\Account;
    use App\Http\Controllers\Auth\RegisterController;
    use App\Payment;
    use App\User;
    use Illuminate\Http\Request;

    use App\Http\Requests;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Redirect;
    use Paystack;


    class PaymentController extends Controller
    {

        /**
         * Redirect the User to Paystack Payment Page
         * @return Url
         */


        public function gateway(Request $request)
        {
           // dd("I got here");exit;
            $validatedData = $request->validate([
                'amount' => 'required',

            ]);



            $paystack  = new Paystack(getenv('PAYSTACK_SECRET_KEY'));



            $rand = new RegisterController();
            $reference = $rand->randomId(10);

            try
            {
                $tranx = $paystack->transaction->initialize([
                    'amount'=>$request->post('amount'),       // in kobo
                    'email'=>Auth::user()->email,         // unique to customers
                    'reference'=>$reference, // unique to transactions
                ]);

               // dd("I got here again");
            } catch(\Yabacon\Paystack\Exception\ApiException $e){
                print_r($e->getResponseObject());
                die($e->getMessage());
            }

            // store transaction reference so we can query in case user never comes back
            // perhaps due to network issue
           // save_last_transaction_reference($tranx->data->reference);

           // dd($tranx->data);
            $transaction =  new Payment();
            $transaction->unique_id = Auth::user()->unique_id;
            $transaction->reference = $reference;
            $transaction->status = 'pending';

            $transaction->save();


            // redirect to page so User can pay
            header('Location: ' . $tranx->data->authorization_url);


            dd("I am here");




        }
        public function redirectToGateway()
        {



            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.paystack.co/transaction/initialize",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => json_encode([
                    'amount'=> 10000,
                    'email'=>Auth::user()->email,
                ]),

                CURLOPT_HTTPHEADER => [
                    "authorization: Bearer sk_test_858bc6de2e4a4e4b138356234bcc15ac99a373d0",
                    "content-type: application/json",
                    "cache-control: no-cache"
                ],
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            if($err){
                // there was an error contacting the Paystack API
              /*  return Redirect::route("loadPayment",['id'=>$request->post('movie_id'),'slug'=>$deta->slug])->with('message',"An error occurred while trying to process your transaction, Please try again Later")->with('type','danger')->with('reference','danger');*/

                die('Curl returned error: ' . $err);
            }



            $tranx = json_decode($response);

            // dd($tranx);

            if(!$tranx->status){
                // there was an error from the API
              /*  return Redirect::route("loadPayment",['id'=>$request->post('movie_id'),'slug'=>$deta->slug])->with('message',$tranx->message)->with('type','danger')->with('reference','danger');*/


                die("error from API");

            }

// store transaction reference so we can query in case user never comes back
// perhaps due to network issue

            $new_payment = new Payment();
            $new_payment->reference = $tranx->data->reference;
            $new_payment->unique_id = Auth::user()->unique_id;
            $new_payment->amount = 10000;
            $new_payment->status = "pending";

            $new_payment->save();

            //save_last_transaction_reference($tranx->data->reference);

// redirect to page so User can pay



            // echo $tranx->data->authorization_url;exit;

            return Redirect::away($tranx->data->authorization_url);


           // return \Unicodeveloper\Paystack\Facades\Paystack::getAuthorizationUrl()->redirectNow();
        }

        /**
         * Obtain Paystack payment information
         * @return void
         */
        public function handleGatewayCallback(Request $request)
        {


          /*
            $paymentDetails = Paystack::getPaymentData();
            dd($paymentDetails);
            $payment = new Payment();
*/

            $route = "showFirstPayment";



            $curl = curl_init();
            $reference = isset($_GET['reference']) ? $_GET['reference'] : '';
            if(!$reference){
//                return Redirect::route("showFirstPayment")->with("message",'An error occured, please contact support')->with("type",'danger');
//                exit;
               die('No reference supplied');
            }



            //Check if the reference exists in the database
            $reference2 = Payment::where('reference',$reference)->first();
            if(count($reference2) < 1){
             // return Redirect::route($route)->with("message",'Invalid transaction')->with("type",'danger');
               // exit;

                die("Referene does not exist");

            }




            //Check if value has already been given to the user
            if(!empty($reference2->status)){
                return Redirect::route("showDashboard")->with("message",'Value already given for this transaction')->with("type",'danger');
                exit;
            }



            //send reference to paystack to verify
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.paystack.co/transaction/verify/".$reference,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    "accept: application/json",
                    "authorization: Bearer sk_test_858bc6de2e4a4e4b138356234bcc15ac99a373d0",
                    "cache-control: no-cache"
                ],
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);


            if($err){


                return Redirect::route($route)->with("message",'Invalid transaction')->with("type",'danger');
                exit;
                // there was an error contacting the Paystack API
              die('Curl returned error: ' . $err);
            }

            dd("I am here1w2");exit;
            $tranx = json_decode($response);

            if(!$tranx->status){
                // there was an error from the API

                return Redirect::route("showFirstPayment")->with("message",$tranx->message)->with("type",'danger');
                die('API returned error: ' . $tranx->message);
            }

          //  dd("I got here");
            if('success' == $tranx->data->status){



                // dd($tranx);
                $paymentDetails = json_decode($response);

                $payment = Payment::where('reference',$paymentDetails->data->reference)->first();

                // dd($paymentDetails);



                //Update transaction table with new details
                $payment->trans_id = $paymentDetails->data->id;
                $payment->currency = $paymentDetails->data->currency;
                $payment->transaction_date = $paymentDetails->data->transaction_date;
                $payment->status = $paymentDetails->data->status;
                $payment->reference = $paymentDetails->data->reference;
                $payment->gateway_response = $paymentDetails->data->gateway_response;
                $payment->ip_address = $paymentDetails->data->ip_address;

                $payment->authorization_code = $paymentDetails->data->authorization->authorization_code;
                $payment->bin = $paymentDetails->data->authorization->bin;
                $payment->last4 = $paymentDetails->data->authorization->last4;
                $payment->exp_month = $paymentDetails->data->authorization->exp_month;
                $payment->exp_year = $paymentDetails->data->authorization->exp_year;
                $payment->channel = $paymentDetails->data->authorization->channel;
                $payment->card_type = $paymentDetails->data->authorization->card_type;
                $payment->bank = $paymentDetails->data->authorization->bank;
                $payment->country_code = $paymentDetails->data->authorization->country_code;
                $payment->brand = $paymentDetails->data->authorization->brand;
                $payment->reusable = $paymentDetails->data->authorization->reusable;
                $payment->signature = $paymentDetails->data->authorization->signature;

                $payment->save();


                $user = User::where("unique_id",$payment->unique_id)->first();

                //check if user has authorization code, else update his authorization for recurrent billings
                if(empty($user ->authorization_code)){
                    $user ->authorization_code = $paymentDetails->data->authorization->authorization_code;
                    $user->save();
                }


                //Update Account Balance
                $balance = Account::where("unique_id",$payment->unique_id)->first();
                $balance->balance  = $balance->balance + $paymentDetails->data->id;;






                echo "Successfully Updated";
               /* if($paymentDetails->data->status == 'success'){

                    $new_qr = Payments::where('reference',$payment->reference)->first();

                    return Redirect::route('showReceipt',['movieId'=>$payment->movie_id,'reference'=> $payment->reference])->with('report','report');

                }else{
                    return Redirect::route("loadPayment",['id'=>$payment->movie_id,'slug'=>$payment->movies->slug])->with('message','An error occured while processing your ticket, please contact our support services if you were debited')->with('type','danger')->with('reference','danger');
                }*/
                // transaction was successful...
                // please check other things like whether you already gave value for this ref
                // if the email matches the customer who owns the product etc
                // Give value
            }


            
            // Now you have the payment details,
            // you can store the authorization_code in your db to allow for recurrent subscriptions
            // you can then redirect or do whatever you want
        }
    }


